from geom2d import Point
import pytest
import math

@pytest.mark.parametrize("a, b, expected", [(Point(1, 1), Point(2, 2), math.sqrt(2))])
def test_distance(a, b, expected):
    assert a.distance(b)==expected